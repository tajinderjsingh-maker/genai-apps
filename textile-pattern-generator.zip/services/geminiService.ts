import { GoogleGenAI } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing in environment variables.");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const generateMotif = async (prompt: string): Promise<string | null> => {
  const client = getClient();
  if (!client) return null;

  try {
    // Using gemini-2.5-flash-image for standard image generation
    // as per guidelines for "General Image Generation"
    const modelId = 'gemini-2.5-flash-image';

    const response = await client.models.generateContent({
      model: modelId,
      contents: {
        parts: [
          {
            text: `Generate a high contrast, seamless textile motif or icon. White background, black foreground. Style: ${prompt}`,
          },
        ],
      },
      config: {
        imageConfig: {
            aspectRatio: "1:1",
        }
      }
    });

    // Iterate through parts to find the image
    if (response.candidates && response.candidates[0] && response.candidates[0].content && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64EncodeString = part.inlineData.data;
          return `data:image/png;base64,${base64EncodeString}`;
        }
      }
    }

    return null;
  } catch (error) {
    console.error("Error generating motif:", error);
    throw error;
  }
};
