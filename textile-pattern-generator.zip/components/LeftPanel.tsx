
import React, { useState } from 'react';
import { Plus, Trash2, Upload, RefreshCw, Download, Eye, EyeOff, Sparkles, Shapes, Leaf, Banana, Cog, Palette, Grid3X3, Move, ArrowRight, Wand2, Layout } from 'lucide-react';
import { PatternState, Motif, PatternType, WeaveType, DistortType } from '../types';
import { GENERATOR_TYPES, REPEAT_STRUCTURES, MOTIF_TEMPLATES, runPatternGenerator, mapStructureToType } from '../constants';
import { generateMotif } from '../services/geminiService';

interface LeftPanelProps {
  pattern: PatternState;
  setPattern: React.Dispatch<React.SetStateAction<PatternState>>;
  motifs: Motif[];
  setMotifs: React.Dispatch<React.SetStateAction<Motif[]>>;
  onExport: (format: 'png' | 'svg') => void;
  seamValid: boolean | null;
  loadingAI: boolean;
  setLoadingAI: (val: boolean) => void;
}

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="border-b border-gray-200 p-4">
    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 flex items-center gap-2">
        {title}
    </h3>
    <div className="space-y-4">{children}</div>
  </div>
);

const SliderGroup: React.FC<{ label: string; value: number; min: number; max: number; step?: number; onChange: (val: number) => void }> = ({ label, value, min, max, step=1, onChange }) => (
    <div>
        <div className="flex justify-between mb-1">
            <span className="text-xs text-gray-600">{label}</span>
            <span className="text-[10px] text-gray-400">{value}</span>
        </div>
        <input 
            type="range" min={min} max={max} step={step} value={value} 
            onChange={(e) => onChange(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-600"
        />
    </div>
);

const LeftPanel: React.FC<LeftPanelProps> = ({ 
  pattern, setPattern, motifs, setMotifs, onExport, seamValid, loadingAI, setLoadingAI 
}) => {
  const [selectedGenerator, setSelectedGenerator] = useState<string>('');
  const [selectedStructure, setSelectedStructure] = useState<string>('');
  const [selectedMotifCategory, setSelectedMotifCategory] = useState<'geometry' | 'organic' | 'fruits' | 'mechanical'>('geometry');
  const [motifPrompt, setMotifPrompt] = useState('');
  const [expandedMotifId, setExpandedMotifId] = useState<string | null>(null);

  // Logic to handle Generator Selection (Visuals)
  const handleGeneratorSelect = (genName: string) => {
    setSelectedGenerator(genName);
    const { state, motifs: newMotifs } = runPatternGenerator(genName);
    const currentName = pattern.projectName !== 'New Pattern' ? pattern.projectName : genName;
    setPattern({ ...state, projectName: currentName });
    setMotifs(newMotifs);
    // Reset structure dropdown to match the default used by the generator
    setSelectedStructure('');
  };

  // Logic to handle Structure Selection (Layout only)
  const handleStructureSelect = (structName: string) => {
    setSelectedStructure(structName);
    const newType = mapStructureToType(structName);
    setPattern(prev => ({ ...prev, repeatType: newType }));
  };

  const handleRegenerateVariation = () => {
    if (!selectedGenerator) return;
    const { state, motifs: newMotifs } = runPatternGenerator(selectedGenerator);
    state.globalScale = 0.5 + Math.random() * 1.5;
    state.palette.background = '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');
    setPattern(p => ({ ...state, projectName: p.projectName }));
    setMotifs(newMotifs.map(m => ({ ...m, rotation: Math.random() * 360 })));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      addMotif(url, e.target.files[0].name);
    }
  };

  const addMotif = (url: string, name: string) => {
    if (motifs.length >= 6) return; 
    const newMotif: Motif = {
      id: Date.now().toString(),
      url,
      name,
      opacity: 1,
      scale: 1,
      rotation: 0,
      x: 0, y: 0, tint: '',
      visible: true
    };
    setMotifs([...motifs, newMotif]);
    setExpandedMotifId(newMotif.id);
  };

  const updateMotif = (id: string, changes: Partial<Motif>) => {
    setMotifs(motifs.map(m => m.id === id ? { ...m, ...changes } : m));
  };

  const removeMotif = (id: string) => {
    setMotifs(motifs.filter(m => m.id !== id));
  };

  const handleAIGenerate = async () => {
    if (!motifPrompt) return;
    setLoadingAI(true);
    try {
      const fullPrompt = `${selectedMotifCategory} style: ${motifPrompt}`;
      const url = await generateMotif(fullPrompt);
      if (url) {
        addMotif(url, `AI: ${motifPrompt.slice(0, 10)}`);
      }
    } catch (e) {
      alert('AI Generation Failed. Check API Key.');
    } finally {
      setLoadingAI(false);
    }
  };

  return (
    <div className="w-[360px] shrink-0 h-full overflow-y-auto bg-white border-r border-gray-200 flex flex-col text-sm shadow-xl z-20">
      <div className="p-4 border-b bg-gray-50 sticky top-0 z-10 shadow-sm">
        <h1 className="text-xl font-extrabold text-brand-900 tracking-tight font-serif">PA Pattern Generator App</h1>
        <div className="flex items-baseline justify-between mt-1">
           <h2 className="text-[10px] font-semibold text-brand-600 uppercase tracking-widest">Seamless Pattern Studio</h2>
           <p className="text-[9px] text-gray-400">by Tajinder J Singh</p>
        </div>
      </div>

      {/* Library & Source */}
      <Section title="Library & Source">
        <div className="space-y-4">
          
          {/* Dropdown 1: Pattern Generator (Visuals) */}
          <div>
            <label className="text-[10px] text-gray-500 block mb-1 font-semibold flex items-center gap-1">
                <Sparkles size={10} /> Pattern Generator (Visual Style)
            </label>
            <div className="relative">
                <select 
                value={selectedGenerator}
                onChange={(e) => handleGeneratorSelect(e.target.value)}
                className="w-full border border-gray-200 bg-white text-gray-800 rounded-md p-2 text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none shadow-sm appearance-none cursor-pointer hover:border-brand-300 transition-colors"
                >
                <option value="" disabled>Select a generator...</option>
                {GENERATOR_TYPES.map(gen => (
                    <option key={gen} value={gen}>{gen}</option>
                ))}
                </select>
                <div className="absolute right-2 top-2 pointer-events-none text-gray-400"><Grid3X3 size={14}/></div>
            </div>
            
             {selectedGenerator && (
             <button 
               onClick={handleRegenerateVariation}
               className="w-full mt-2 py-1.5 bg-brand-50 text-brand-700 border border-brand-200 rounded-md text-[10px] font-bold uppercase tracking-wide flex items-center justify-center gap-2 hover:bg-brand-100 transition-colors"
             >
                <Wand2 size={12} /> Regenerate Variation
             </button>
            )}
          </div>

          {/* Dropdown 2: Repeat Structure (Layout) */}
          <div className="pt-2 border-t border-gray-100">
             <label className="text-[10px] text-gray-500 block mb-1 font-semibold flex items-center gap-1">
                <Layout size={10} /> Repeat Structure (Layout Override)
             </label>
             <div className="relative">
                <select 
                    value={selectedStructure}
                    onChange={(e) => handleStructureSelect(e.target.value)}
                    className="w-full border border-gray-200 bg-white text-gray-800 rounded-md p-2 text-xs focus:ring-1 focus:ring-brand-500 focus:outline-none shadow-sm appearance-none cursor-pointer hover:border-brand-300 transition-colors"
                >
                    <option value="" disabled>Override default layout...</option>
                    {REPEAT_STRUCTURES.map(s => (
                    <option key={s} value={s}>{s}</option>
                    ))}
                </select>
                <div className="absolute right-2 top-2 pointer-events-none text-gray-400"><Move size={14}/></div>
             </div>
          </div>

        </div>
      </Section>

      {/* Motif Generator */}
      <Section title="Motif Generator">
         <div className="flex gap-1 mb-3 bg-gray-50 p-1 rounded-lg border border-gray-100">
            {[
              { id: 'geometry', icon: <Shapes size={14} />, label: 'Geo' },
              { id: 'organic', icon: <Leaf size={14} />, label: 'Org' },
              { id: 'fruits', icon: <Banana size={14} />, label: 'Nat' },
              { id: 'mechanical', icon: <Cog size={14} />, label: 'Mec' }
            ].map((type) => (
              <button
                key={type.id}
                onClick={() => setSelectedMotifCategory(type.id as any)}
                className={`flex-1 flex flex-col items-center py-2 rounded text-[10px] transition-all ${
                  selectedMotifCategory === type.id 
                    ? 'bg-white shadow-sm text-brand-600 font-bold border border-gray-200' 
                    : 'text-gray-500 hover:bg-gray-200'
                }`}
              >
                {type.icon}
                <span className="mt-1">{type.label}</span>
              </button>
            ))}
         </div>

         {/* Quick Shapes Grid */}
         <div className="grid grid-cols-5 gap-2 mb-3">
            {MOTIF_TEMPLATES[selectedMotifCategory].map((t, i) => (
              <button
                key={i}
                onClick={() => addMotif(t.svg, t.name)}
                className="aspect-square border border-gray-100 rounded bg-white hover:border-brand-500 hover:shadow-md flex items-center justify-center p-1 transition-all group"
                title={`Add ${t.name}`}
              >
                <img src={t.svg} className="w-full h-full object-contain opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-transform" alt={t.name} />
              </button>
            ))}
         </div>

         {/* AI Input */}
         <div className="flex gap-2 items-center">
            <div className="relative flex-1">
                 <input 
                type="text" 
                value={motifPrompt} 
                onChange={e => setMotifPrompt(e.target.value)}
                placeholder="AI Prompt..."
                className="w-full border border-gray-200 bg-white text-gray-800 rounded-md pl-2 pr-2 py-2 text-xs focus:border-brand-500 focus:outline-none shadow-sm placeholder-gray-300"
                />
            </div>
           
            <button 
              onClick={handleAIGenerate}
              disabled={loadingAI}
              className="bg-brand-600 text-white px-3 py-2 rounded-md hover:bg-brand-700 disabled:opacity-50 text-xs font-medium flex items-center gap-1 shadow-sm"
            >
              <Sparkles size={12} />
            </button>
         </div>
         
         <div className="mt-3">
           <label className="cursor-pointer border border-dashed border-gray-300 bg-gray-50 text-gray-600 px-3 py-2 rounded text-xs hover:bg-white hover:border-brand-400 hover:text-brand-600 flex items-center justify-center gap-2 transition-colors">
             <Upload size={14} /> Upload Custom Image
             <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
           </label>
         </div>
      </Section>

      {/* Motif Manager */}
      <Section title="Active Layers">
        <div className="space-y-2">
          {motifs.map((m) => {
            const isExpanded = expandedMotifId === m.id;
            return (
            <div key={m.id} className={`bg-white rounded border transition-colors ${isExpanded ? 'border-brand-400 ring-1 ring-brand-100' : 'border-gray-200'}`}>
              <div className="flex items-center gap-2 p-2">
                <div 
                    className="w-8 h-8 bg-gray-50 border rounded flex items-center justify-center cursor-pointer overflow-hidden"
                    onClick={() => setExpandedMotifId(isExpanded ? null : m.id)}
                >
                    <img src={m.url} className="w-full h-full object-contain" alt="" />
                </div>
                <div 
                    className="flex-1 min-w-0 cursor-pointer"
                    onClick={() => setExpandedMotifId(isExpanded ? null : m.id)}
                >
                    <div className="text-xs font-bold text-gray-700 truncate">{m.name}</div>
                </div>
                <button onClick={() => updateMotif(m.id, { visible: !m.visible })} className="text-gray-400 hover:text-brand-600 p-1">
                  {m.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
                <button onClick={() => removeMotif(m.id)} className="text-gray-400 hover:text-red-600 p-1">
                  <Trash2 size={14} />
                </button>
              </div>
              
              {/* Expanded Controls */}
              {isExpanded && (
                  <div className="p-2 bg-gray-50 border-t border-gray-100 grid grid-cols-2 gap-x-3 gap-y-2">
                      <SliderGroup label="Scale" value={m.scale} min={0.1} max={5} step={0.1} onChange={(v) => updateMotif(m.id, { scale: v })} />
                      <SliderGroup label="Rotation" value={m.rotation} min={0} max={360} step={5} onChange={(v) => updateMotif(m.id, { rotation: v })} />
                      <SliderGroup label="Pos X" value={m.x} min={-100} max={100} onChange={(v) => updateMotif(m.id, { x: v })} />
                      <SliderGroup label="Pos Y" value={m.y} min={-100} max={100} onChange={(v) => updateMotif(m.id, { y: v })} />
                      <SliderGroup label="Opacity" value={m.opacity} min={0} max={1} step={0.1} onChange={(v) => updateMotif(m.id, { opacity: v })} />
                      
                      <div>
                        <label className="text-xs text-gray-600 block mb-1">Tint</label>
                        <div className="flex gap-2">
                            <input type="color" value={m.tint || '#000000'} onChange={(e) => updateMotif(m.id, { tint: e.target.value })} className="w-6 h-6 rounded cursor-pointer border-none p-0" />
                            <button onClick={() => updateMotif(m.id, { tint: '' })} className="text-[10px] text-gray-500 underline">Reset</button>
                        </div>
                      </div>
                  </div>
              )}
            </div>
          )})}
        </div>
      </Section>

      {/* Tile & Layout */}
      <Section title="Tile & Layout">
        <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
                <div>
                    <label className="text-[10px] text-gray-500 font-semibold block mb-1">Tile Size</label>
                    <input 
                    type="number" value={pattern.tileSize}
                    onChange={e => setPattern({...pattern, tileSize: parseInt(e.target.value)})}
                    className="w-full border border-gray-200 bg-white text-gray-900 rounded p-1.5 text-xs focus:outline-none focus:border-brand-500 shadow-sm"
                    />
                </div>
                 <div>
                    <label className="text-[10px] text-gray-500 font-semibold block mb-1">Density</label>
                    <input 
                        type="range" min="1" max="10" 
                        value={pattern.density}
                        onChange={e => setPattern({...pattern, density: parseInt(e.target.value)})}
                        className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-600 mt-2"
                    />
                </div>
            </div>
            
            <SliderGroup label="Global Scale" value={pattern.globalScale} min={0.1} max={3} step={0.1} onChange={(v) => setPattern({...pattern, globalScale: v})} />
            <SliderGroup label="Global Rotation" value={pattern.globalRotation} min={0} max={360} step={5} onChange={(v) => setPattern({...pattern, globalRotation: v})} />
            
            <div className="grid grid-cols-2 gap-3">
                <SliderGroup label="Spacing X" value={pattern.spacingX} min={-100} max={100} onChange={(v) => setPattern({...pattern, spacingX: v})} />
                <SliderGroup label="Spacing Y" value={pattern.spacingY} min={-100} max={100} onChange={(v) => setPattern({...pattern, spacingY: v})} />
            </div>
        </div>
      </Section>

      {/* Color */}
      <Section title="Palette">
        <div className="grid grid-cols-4 gap-2 mb-3">
            {[
                { label: 'Bg', key: 'background' },
                { label: 'Pri', key: 'primary' },
                { label: 'Sec', key: 'secondary' },
                { label: 'Acc', key: 'accent' }
            ].map(col => (
                <div key={col.key} className="flex flex-col items-center">
                <div className="relative w-8 h-8 overflow-hidden rounded-full shadow ring-1 ring-gray-200 transition-transform hover:scale-110">
                    <input 
                        type="color" 
                        value={(pattern.palette as any)[col.key]} 
                        onChange={e => setPattern(p => ({...p, palette: {...p.palette, [col.key]: e.target.value}}))}
                        className="absolute -top-4 -left-4 w-16 h-16 cursor-pointer p-0 border-0"
                    />
                </div>
                <span className="text-[9px] mt-1 text-gray-500 uppercase font-bold">{col.label}</span>
                </div>
            ))}
        </div>
        <button 
           onClick={() => {
             const r = () => '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');
             setPattern(p => ({ ...p, palette: { background: r(), primary: r(), secondary: r(), accent: r() } }));
           }}
           className="w-full py-1.5 border border-gray-200 rounded text-xs bg-gray-50 hover:bg-white hover:text-brand-600 flex items-center justify-center gap-2 text-gray-600 font-medium transition-colors"
        >
            <RefreshCw size={12} /> Randomize Colors
        </button>
      </Section>

      {/* Texture & Finish */}
      <Section title="Texture & Finish">
         <div className="space-y-4">
             <div className="grid grid-cols-2 gap-3">
                 <SliderGroup label="Blur" value={pattern.texture.blur} min={0} max={10} step={0.5} onChange={(v) => setPattern(p => ({...p, texture: {...p.texture, blur: v}}))} />
                 <SliderGroup label="Roughness" value={pattern.texture.roughness} min={0} max={100} onChange={(v) => setPattern(p => ({...p, texture: {...p.texture, roughness: v}}))} />
             </div>
             <SliderGroup label="Overprint" value={pattern.texture.overprint} min={0} max={100} onChange={(v) => setPattern(p => ({...p, texture: {...p.texture, overprint: v}}))} />
             
             <div>
                <label className="text-[10px] text-gray-500 font-semibold block mb-1">Distort Effect</label>
                <select 
                  value={pattern.texture.distortType}
                  onChange={e => setPattern(p => ({...p, texture: {...p.texture, distortType: e.target.value as DistortType}}))}
                  className="w-full border border-gray-200 bg-white text-gray-900 rounded p-2 text-xs focus:outline-none focus:border-brand-500 shadow-sm mb-2"
                >
                   {['None', 'Noise', 'Wave', 'Marble', 'Glitch', 'Turbulence'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
                {pattern.texture.distortType !== 'None' && (
                     <SliderGroup label="Intensity" value={pattern.texture.distortIntensity} min={0} max={100} onChange={(v) => setPattern(p => ({...p, texture: {...p.texture, distortIntensity: v}}))} />
                )}
             </div>
         </div>
      </Section>

      {/* Weave Generator */}
      <Section title="Weave Generator">
          <div className="space-y-3">
             <div className="flex items-center justify-between">
                 <label className="text-xs font-medium text-gray-700">Enable Weave</label>
                 <input 
                    type="checkbox" checked={pattern.weave.enabled}
                    onChange={e => setPattern(p => ({...p, weave: {...p.weave, enabled: e.target.checked}}))}
                    className="toggle-checkbox rounded border-gray-300 text-brand-600 focus:ring-brand-500"
                 />
             </div>
             
             {pattern.weave.enabled && (
                 <div className="space-y-3 pt-2 bg-gray-50/50 p-2 rounded border border-gray-100">
                     <div className="grid grid-cols-2 gap-3">
                         <div className="col-span-2">
                             <label className="text-[10px] text-gray-500 block mb-1 font-semibold">Weave Structure</label>
                             <select 
                                value={pattern.weave.type}
                                onChange={e => setPattern(p => ({...p, weave: {...p.weave, type: e.target.value as WeaveType}}))}
                                className="w-full border border-gray-200 bg-white text-gray-900 rounded p-2 text-xs focus:outline-none focus:border-brand-500"
                             >
                                {Object.values(WeaveType).map(t => <option key={t} value={t}>{t}</option>)}
                             </select>
                         </div>
                         <div>
                             <label className="text-[10px] text-gray-500 block mb-1 font-semibold">Base Color</label>
                             <div className="flex items-center gap-2">
                                <input type="color" value={pattern.weave.color} onChange={e => setPattern(p => ({...p, weave: {...p.weave, color: e.target.value}}))} className="w-full h-8 rounded cursor-pointer border border-gray-200 p-0" />
                             </div>
                         </div>
                         <div className="flex items-end">
                            <span className="text-[9px] text-gray-400">Select base thread color</span>
                         </div>
                     </div>

                     <SliderGroup label="Scale" value={pattern.weave.scale} min={0.5} max={3} step={0.1} onChange={(v) => setPattern(p => ({...p, weave: {...p.weave, scale: v}}))} />
                     <SliderGroup label="Rotation" value={pattern.weave.rotation} min={0} max={180} step={5} onChange={(v) => setPattern(p => ({...p, weave: {...p.weave, rotation: v}}))} />
                     <SliderGroup label="Threads (Density)" value={pattern.weave.threads} min={10} max={100} step={5} onChange={(v) => setPattern(p => ({...p, weave: {...p.weave, threads: v}}))} />
                     <SliderGroup label="Depth (Shadow)" value={pattern.weave.depth} min={0} max={100} step={10} onChange={(v) => setPattern(p => ({...p, weave: {...p.weave, depth: v}}))} />
                     <SliderGroup label="Opacity" value={pattern.weave.opacity} min={0} max={100} onChange={(v) => setPattern(p => ({...p, weave: {...p.weave, opacity: v}}))} />
                 </div>
             )}
          </div>
      </Section>

      {/* Export */}
      <Section title="Export Project">
         <div className="space-y-3">
            <div className="space-y-1">
                <label className="text-[10px] text-gray-500 font-semibold">Project Name</label>
                <input 
                  type="text" placeholder="Project Name"
                  value={pattern.projectName}
                  onChange={e => setPattern({...pattern, projectName: e.target.value})}
                  className="w-full border border-gray-200 bg-white text-gray-900 rounded px-2 py-1.5 text-sm focus:outline-none focus:border-brand-500 shadow-sm placeholder-gray-300"
                />
            </div>
            
            <div className="flex items-center justify-between bg-blue-50 p-2 rounded border border-blue-100 mt-2">
                <span className="text-blue-800 font-medium text-xs">Seam Check</span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${seamValid ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'}`}>
                    {seamValid ? 'PASS' : '...'}
                </span>
            </div>

            <div className="flex gap-2 pt-2">
                <button 
                  onClick={() => onExport('png')}
                  className="flex-1 bg-brand-600 text-white py-2.5 rounded-md shadow-sm flex items-center justify-center gap-2 hover:bg-brand-700 font-medium transition-colors text-xs"
                >
                   <Download size={14} /> Export PNG
                </button>
                 <button 
                  onClick={() => onExport('svg')}
                  className="flex-1 border border-gray-300 bg-white text-gray-700 py-2.5 rounded-md shadow-sm flex items-center justify-center gap-2 hover:bg-gray-50 font-medium transition-colors text-xs"
                >
                   <Download size={14} /> Export SVG
                </button>
            </div>
         </div>
      </Section>
      
      <div className="h-10 shrink-0"></div>
    </div>
  );
};

export default LeftPanel;
