
import React, { useEffect, useRef, useState } from 'react';
import { PatternState, PatternType, Motif, WeaveType } from '../types';

interface CanvasPreviewProps {
  pattern: PatternState;
  motifs: Motif[];
  showSeamlines: boolean;
  showGrid: boolean;
  zoom: number;
  onValidateSeam?: (valid: boolean) => void;
}

const CanvasPreview: React.FC<CanvasPreviewProps> = ({
  pattern,
  motifs,
  showSeamlines,
  showGrid,
  zoom,
  onValidateSeam
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [loadedImages, setLoadedImages] = useState<Record<string, HTMLImageElement>>({});

  // Preload images
  useEffect(() => {
    const newImages: Record<string, HTMLImageElement> = {};
    let loadedCount = 0;
    const totalRequired = motifs.filter(m => m.visible).length;

    if (totalRequired === 0) {
       setLoadedImages({});
       return;
    }

    motifs.forEach(motif => {
      if (!motif.visible) return;
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = motif.url;
      img.onload = () => {
        newImages[motif.id] = img;
        loadedCount++;
        if (loadedCount === totalRequired) {
          setLoadedImages(prev => ({ ...prev, ...newImages }));
        }
      };
      // Handle svg load errors or empty srcs
      img.onerror = () => {
          loadedCount++;
          if (loadedCount === totalRequired) setLoadedImages(prev => ({ ...prev, ...newImages }));
      }
    });
  }, [motifs]);

  // Helper to Generate Weave Texture
  const generateWeaveTexture = (width: number, height: number): HTMLCanvasElement | null => {
      if (!pattern.weave.enabled) return null;
      
      const wCanvas = document.createElement('canvas');
      // Size based on scale/threads. 
      // threads=10 -> big chunks, threads=100 -> fine
      const scale = pattern.weave.scale || 1;
      const density = Math.max(5, 110 - (pattern.weave.threads || 50)); 
      const tileSize = density * scale;
      
      // We generate a seamless tile for the specific weave type
      let cols = 2, rows = 2;
      
      switch(pattern.weave.type) {
          case WeaveType.Plain: cols=2; rows=2; break;
          case WeaveType.Basket: cols=4; rows=4; break;
          case WeaveType.Twill: cols=4; rows=4; break;
          case WeaveType.Satin: cols=5; rows=5; break;
          case WeaveType.Herringbone: cols=8; rows=4; break;
          case WeaveType.Oxford: cols=4; rows=4; break;
          case WeaveType.Dobby: cols=6; rows=6; break;
          default: cols=2; rows=2;
      }
      
      wCanvas.width = tileSize * cols;
      wCanvas.height = tileSize * rows;
      const ctx = wCanvas.getContext('2d');
      if (!ctx) return null;

      // Background (Main color)
      ctx.fillStyle = pattern.weave.color;
      ctx.fillRect(0, 0, wCanvas.width, wCanvas.height);

      // Shadow/Depth Color
      const depth = (pattern.weave.depth || 50) / 100;
      ctx.fillStyle = `rgba(0,0,0,${depth * 0.6})`;

      const drawRect = (c: number, r: number) => {
          ctx.fillRect(c * tileSize, r * tileSize, tileSize, tileSize);
      };

      // Draw 'Under' threads (shadows)
      for(let r=0; r<rows; r++) {
          for(let c=0; c<cols; c++) {
              let isUnder = false;
              
              if (pattern.weave.type === WeaveType.Plain) {
                  isUnder = (c+r) % 2 !== 0;
              }
              else if (pattern.weave.type === WeaveType.Basket) {
                  // 2x2 Basket
                  isUnder = (Math.floor(c/2) + Math.floor(r/2)) % 2 !== 0;
              }
              else if (pattern.weave.type === WeaveType.Twill) {
                  // 1/3 Twill
                  isUnder = (c + r) % 4 === 0;
              }
              else if (pattern.weave.type === WeaveType.Satin) {
                  // 5-harness satin
                   // steps: 0,2,4,1,3
                   const steps = [0, 2, 4, 1, 3];
                   isUnder = steps[r] === c;
              }
              else if (pattern.weave.type === WeaveType.Herringbone) {
                  // Zigzag
                  const x = c % 4;
                  const y = r % 4;
                  if (c < 4) isUnder = (x + y) % 4 === 0; // Left lean
                  else isUnder = (x - y + 4) % 4 === 0; // Right lean
              }
              else if (pattern.weave.type === WeaveType.Oxford) {
                  // 2x1 Basket variation
                   if (c%2===0 && r%2===0) isUnder=true;
                   if (c%2!==0 && r%2!==0) isUnder=true;
              }
              
              if (isUnder) {
                  // Draw shadow to simulate thread going under
                  drawRect(c, r);
                  
                  // Add highlight for realism
                  ctx.fillStyle = `rgba(255,255,255,${depth * 0.2})`;
                  ctx.fillRect(c * tileSize, r * tileSize, tileSize * 0.2, tileSize);
                  ctx.fillStyle = `rgba(0,0,0,${depth * 0.6})`; // Reset to shadow
              } else {
                   // "Over" threads get a small highlight
                   ctx.save();
                   ctx.fillStyle = `rgba(255,255,255,${depth * 0.15})`;
                   ctx.fillRect(c * tileSize, r * tileSize, tileSize, tileSize * 0.2);
                   ctx.restore();
              }
          }
      }
      
      return wCanvas;
  };

  // Main Drawing Logic
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.clearRect(0, 0, width, height);
    
    // Background
    ctx.fillStyle = pattern.palette.background;
    ctx.fillRect(0, 0, width, height);

    const size = pattern.tileSize * zoom;
    
    // Optimize loop range
    const cols = Math.ceil(width / size) + 3;
    const rows = Math.ceil(height / size) + 3;
    const startX = -size * 1.5;
    const startY = -size * 1.5;

    // Density Factor (1-10) -> Scale Factor (0.2 to 1.8)
    const densityScaleFactor = 0.2 + (pattern.density * 0.16);

    // Apply Base CSS Filters for texture (Blur, Roughness via contrast)
    let filterString = '';
    if (pattern.texture.blur > 0) {
        filterString += `blur(${pattern.texture.blur}px) `;
    }
    if (pattern.texture.roughness > 0) {
        // Roughness: Blur then high contrast to create jagged edges
        const roughnessBlur = Math.max(0.5, pattern.texture.roughness / 30);
        filterString += `contrast(${100 + pattern.texture.roughness * 3}%) blur(${roughnessBlur}px) `;
    }
    ctx.filter = filterString.trim() || 'none';

    // Helper for tinting
    const drawTinted = (img: HTMLImageElement, x: number, y: number, w: number, h: number, tint: string, opacity: number) => {
        // Create offscreen buffer for tinting if needed
        if (tint) {
            const buffer = document.createElement('canvas');
            buffer.width = img.width;
            buffer.height = img.height;
            const bx = buffer.getContext('2d');
            if (bx) {
                bx.drawImage(img, 0, 0);
                bx.globalCompositeOperation = 'source-in';
                bx.fillStyle = tint;
                bx.fillRect(0, 0, buffer.width, buffer.height);
                ctx.globalAlpha = opacity;
                ctx.drawImage(buffer, x, y, w, h);
                return;
            }
        } 
        ctx.globalAlpha = opacity;
        ctx.drawImage(img, x, y, w, h);
    };

    // Tiling Loop
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        let x = startX + c * size;
        let y = startY + r * size;
        
        // Standard Offsets
        x += pattern.offsetX;
        y += pattern.offsetY;
        x += c * pattern.spacingX * zoom;
        y += r * pattern.spacingY * zoom;

        // Repeat Logic
        if (pattern.repeatType === PatternType.Brick) {
          if (r % 2 !== 0) x += size * 0.5;
        } else if (pattern.repeatType === PatternType.HalfDrop) {
          if (c % 2 !== 0) y += size * 0.5;
        } else if (pattern.repeatType === PatternType.Diamond) {
            if (r % 2 !== 0) x += size * 0.5;
            // Squeeze height for diamond effect
            y -= r * (size * 0.2); 
        } else if (pattern.repeatType === PatternType.Ogee) {
             if (c % 2 !== 0) y += size * 0.5;
             // Curvy offsets could be complex, simplifying to half drop var
        } else if (pattern.repeatType === PatternType.Hex) {
            if (r % 2 !== 0) x += size * 0.5;
            y -= r * (size * 0.14); // Hex vertical packing
        }

        ctx.save();
        ctx.translate(x, y);

        // Mirroring
        if (pattern.repeatType === PatternType.Mirror) {
            if (c % 2 !== 0) ctx.scale(-1, 1);
            if (r % 2 !== 0) ctx.scale(1, -1);
        }
        
        // Random Toss Rotation
        let tossRotation = 0;
        if (pattern.repeatType === PatternType.Toss) {
            // deterministic random based on grid pos
            const seed = r * 1000 + c;
            tossRotation = (Math.sin(seed) * 360);
        }

        // Grid Overlay (Tile Bounds)
        if (showGrid) {
          ctx.save();
          ctx.filter = 'none';
          ctx.strokeStyle = 'rgba(0,0,0,0.1)';
          ctx.lineWidth = 1;
          ctx.strokeRect(0, 0, size, size);
          ctx.restore();
        }

        // Draw Motifs
        motifs.forEach((motif, idx) => {
          if (!motif.visible || !loadedImages[motif.id]) return;
          const img = loadedImages[motif.id];

          ctx.save();
          
          // Center of Tile
          ctx.translate(size / 2, size / 2);
          
          // Global Rotation
          ctx.rotate((pattern.globalRotation * Math.PI) / 180);
          
          // Toss Rotation
          ctx.rotate((tossRotation * Math.PI) / 180);

          // Individual Motif Transform
          // Convert percentage offset to pixels based on tile size
          const mx = (motif.x / 100) * size;
          const my = (motif.y / 100) * size;
          ctx.translate(mx, my);

          // Motif Rotation
          ctx.rotate((motif.rotation * Math.PI) / 180);

          // Scaling
          const finalScale = motif.scale * (size / 300) * pattern.globalScale * densityScaleFactor; 
          ctx.scale(finalScale, finalScale);
          
          // Draw
          drawTinted(img, -img.width / 2, -img.height / 2, img.width, img.height, motif.tint, motif.opacity);
          
          ctx.restore();
        });

        ctx.restore();
      }
    }

    ctx.filter = 'none';

    // Overprint (Multiply)
    if (pattern.texture.overprint > 0) {
        ctx.globalCompositeOperation = 'multiply';
        ctx.fillStyle = `rgba(30, 30, 15, ${pattern.texture.overprint / 150})`; 
        ctx.fillRect(0, 0, width, height);
        ctx.globalCompositeOperation = 'source-over';
    }

    // Weave Overlay
    if (pattern.weave.enabled) {
        const weaveTile = generateWeaveTexture(width, height);
        if (weaveTile) {
            ctx.save();
            ctx.globalAlpha = pattern.weave.opacity / 100;
            ctx.globalCompositeOperation = 'overlay'; // Often better for textures

            // Create a large enough canvas to hold rotated pattern
            // Rotation of pattern fills is tricky in Canvas API
            // So we fill a rect, then rotate context
            
            // Or better: Use setTransform on the pattern if needed, but standard API 
            // support is mixed. 
            // Alternative: Rotate the context, draw a giant rect.
            
            const diag = Math.sqrt(width*width + height*height);
            ctx.translate(width/2, height/2);
            ctx.rotate((pattern.weave.rotation || 0) * Math.PI / 180);
            ctx.translate(-diag, -diag); // Move back enough to cover rotation
            
            const patternFill = ctx.createPattern(weaveTile, 'repeat');
            if (patternFill) {
                ctx.fillStyle = patternFill;
                ctx.fillRect(0, 0, diag*2, diag*2);
            }
            
            ctx.restore();
        }
    }

    // Seamlines
    if (showSeamlines) {
        ctx.strokeStyle = '#ec4899';
        ctx.setLineDash([5, 5]);
        ctx.lineWidth = 2;
        const cx = width / 2 - size / 2;
        const cy = height / 2 - size / 2;
        ctx.strokeRect(cx, cy, size, size);
        if (onValidateSeam) onValidateSeam(true);
    }

  }, [pattern, motifs, loadedImages, zoom, showGrid, showSeamlines]);

  // Resize Listener
  useEffect(() => {
    const resize = () => {
      if (canvasRef.current && containerRef.current) {
        canvasRef.current.width = containerRef.current.clientWidth;
        canvasRef.current.height = containerRef.current.clientHeight;
      }
    };
    window.addEventListener('resize', resize);
    resize();
    return () => window.removeEventListener('resize', resize);
  }, []);

  // SVG Filters Definitions
  const distortionFilterStyle = {
      filter: pattern.texture.distortType !== 'None' ? `url(#distort-${pattern.texture.distortType})` : 'none'
  };

  const intensity = pattern.texture.distortIntensity || 0;

  return (
    <div ref={containerRef} className="w-full h-full bg-gray-100 overflow-hidden relative pattern-bg">
      {/* SVG Filter Definitions */}
      <svg width="0" height="0" className="absolute pointer-events-none">
          <defs>
              <filter id="distort-Noise">
                  <feTurbulence type="fractalNoise" baseFrequency={`${0.01 + (intensity/2000)}`} numOctaves="3" result="noise" />
                  <feDisplacementMap in="SourceGraphic" in2="noise" scale={`${intensity}`} />
              </filter>
              <filter id="distort-Wave">
                  <feTurbulence type="turbulence" baseFrequency="0.02 0.05" numOctaves="2" result="turbulence" />
                  <feDisplacementMap in="SourceGraphic" in2="turbulence" scale={`${intensity}`} xChannelSelector="R" yChannelSelector="G" />
              </filter>
              <filter id="distort-Marble">
                   <feTurbulence baseFrequency="0.002 0.008" numOctaves="3" result="noise" seed="4"/>
                   <feDisplacementMap in="SourceGraphic" in2="noise" scale={`${intensity * 2}`} />
              </filter>
              <filter id="distort-Glitch">
                   <feTurbulence type="turbulence" baseFrequency="0.5 0.0" numOctaves="1" result="noise" />
                   <feDisplacementMap in="SourceGraphic" in2="noise" scale={`${intensity / 2}`} />
              </filter>
               <filter id="distort-Turbulence">
                   <feTurbulence baseFrequency="0.05" numOctaves="2" result="noise"/>
                   <feDisplacementMap in="SourceGraphic" in2="noise" scale={`${intensity}`} />
              </filter>
          </defs>
      </svg>

      <canvas 
        ref={canvasRef} 
        className="block w-full h-full"
        style={distortionFilterStyle}
      />
    </div>
  );
};

export default CanvasPreview;
